﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PS11905_BAODUONG_ASM.Models.ViewModels
{
    public class ViewCart
    {
        public MonAn MonAn { get; set; }
        public int Quantity { get; set; }
    }
}
